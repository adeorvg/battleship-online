package Gra;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class LoggingFrame extends JFrame
{   
	private ClientSocket client;
	
	private Dimension loggingFrameSize;
	
	private JPanel	loggingPanel;
	
	private JLabel loginText;
	
	private JLabel passwordText;
	
	private JTextArea loginInputText;
	
	private JTextArea passwordInputText;
	
	private JButton loggingBtn;
	
	private JButton registerBtn;
	
	private SettingShipsFrame shipsFrame;
	
	
	LoggingFrame(ClientSocket Client)
	{   
		this.client = Client;
		setTitle("Zaloguj siê");
		loggingFrameSize = new Dimension(400, 300);
		setPreferredSize(loggingFrameSize);
		pack();
		setLocationRelativeTo(null);
		//setLayout(null);
		createUI();
	}
	
	private void createUI()
	{
		loggingPanel = new JPanel();
		loggingPanel.setBackground(new Color(8,127,198));
		Font myFont = new Font("Arial",Font.PLAIN,18);
		loginText = new JLabel("Login:");
		loginText.setFont(myFont);
		loggingPanel.add(loginText);
		loginInputText = new JTextArea();
		loginInputText.setFont(myFont);
		loginInputText.setPreferredSize(new Dimension(200,25));
		//loginInputText.setBounds(0,0,100,20);
		loggingPanel.add(loginInputText);
		passwordText = new JLabel("Has³o:");
		passwordText.setFont(myFont);
		loggingPanel.add(passwordText);
		passwordInputText = new JTextArea();
		passwordInputText.setFont(myFont);
		passwordInputText.setPreferredSize(new Dimension(200,25));
		loggingPanel.add(passwordInputText);
		HandlerClass handler = new HandlerClass();
		loggingBtn = new JButton("Zaloguj");
		loggingBtn.addActionListener(handler);
		loggingPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 40, 40));
		loggingPanel.add(loggingBtn);
		registerBtn = new JButton("Zarejestruj siê :)");
		registerBtn.addActionListener(handler);
		loggingPanel.add(registerBtn);
		this.add(loggingPanel);
		
	}
	
	private void makeSettingShipsWindow()
	{   
		this.setVisible(false);
		shipsFrame = new SettingShipsFrame(client);
		shipsFrame.setVisible(true);
	}
	
	private void makeRegisterWindow()
	{
		
	}
	
	private class HandlerClass implements ActionListener{
		public void actionPerformed(ActionEvent event) {
			if(event.getSource()==loggingBtn) {
				makeSettingShipsWindow();
			}
			if(event.getSource()==registerBtn)
			{
				makeRegisterWindow();
			}
		}
	}
	
}
