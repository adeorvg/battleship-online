package centralServer;

class Main {
	public static void main(String[] args) throws Exception {
		AppStart.serverStart();
	}
}
