import java.net.*;
import java.io.*;
import java.util.*;
public class Client 
{
	public static void main (String[] args) throws IOException
	{
		Socket socket = new Socket("localhost", 5050);
		OutputStream os = socket.getOutputStream();
		PrintWriter pw = new PrintWriter(os, true);//to server
		InputStream is = socket.getInputStream();//from server
		BufferedReader br = new BufferedReader(new InputStreamReader (is));
		Scanner usr_scanner = new Scanner (System.in);//not so important                                       <-    
		BufferedReader usr = new BufferedReader(new InputStreamReader (System.in));//reader from user like that |
		String FromServer;
		String FromUser;
		while (true)
		{
			FromUser = usr_scanner.nextLine();
			pw.println(FromUser);
			pw.flush();//important
			FromServer=br.readLine();
			System.out.println("From Server "+FromServer);
			if (FromServer.equals("Oh no"))
			{
				socket.close();
			}
	    }
	    
   }
}

