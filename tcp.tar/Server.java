import java.net.*;
import java.io.*;
public class  Server 
{
	public static void main (String[] args) throws IOException 
	{
		
	   ServerSocket server = new ServerSocket(5050);
	   Socket socket = server.accept();
	   InputStream is = socket.getInputStream();//stream from client
	   BufferedReader br = new BufferedReader( new InputStreamReader (is));//reader from client
       OutputStream os = socket.getOutputStream();//stream to client
       PrintWriter pw = new PrintWriter(os, true);//writer to client
       String FromClient;	
		while (true)
		 { 
	       
	       FromClient = br.readLine();
		   if (FromClient.equals("q")) 
			 {
				 pw.println("Oh no");
				 pw.flush();//really, really important
				 socket.close();
		     }
		   System.out.println("From Client "+FromClient);
		   pw.println("Ok");
		   pw.flush();//important
		   
		 }
				
	}
}

